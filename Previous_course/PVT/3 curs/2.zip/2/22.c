#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>

const int n = 100000000;

double getrand()
{
    int r = rand();
    while (r == 0 || r == RAND_MAX)
    {
        r = rand();
    }
    return (double)r / RAND_MAX;
}

double func(double x, double y)
{
    return x / ( y * y);
}

int main(int argc, char **argv)
{
    int commsize, rank;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &commsize);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    double time = 0.0;
    time -= MPI_Wtime();

    srand(rank);
    int in = 0;
    double s = 0;
    for (int i = rank; i < n; i += commsize)
    {
        double x = getrand();         //(0, 1)
        double y = getrand() * 3 + 2; //(2, 5)
        if ((y > 2) && (y < 5))
        {
            in++;
            s += func(x, y);
        }
    }

    int gin = 0;
    MPI_Reduce(&in, &gin, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
    double gsum = 0.0;
    MPI_Reduce(&s, &gsum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        double v = gin / n;
        double res = v * gsum / gin;

        time += MPI_Wtime();

        printf("Result: %.12f, n %d\n", res, n);
        printf("Elapsed time (sec.): %.6f\n", time);
    }

    MPI_Finalize();
    return 0;
}
